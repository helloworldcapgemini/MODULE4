﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_client
{
    /// <summary>
    /// Interaction logic for GetOrderStatus.xaml
    /// </summary>
    public partial class GetOrderStatus : Window
    {
        public GetOrderStatus()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            ServiceReference1.ServiceClient client = new ServiceReference1.ServiceClient("WSHttpBinding_IService");
            
            int orderid = Convert.ToInt32(txt_orderid.Text);
            client.GetOrderStatusCompleted += client_GetOrderStatusCompleted;
            client.GetOrderStatusAsync(orderid);
            //string status = client.GetOrderStatus(orderid);
            //txt_Status.Text = status;
            MessageBox.Show("Main Thread");
        }

        void client_GetOrderStatusCompleted(object sender, ServiceReference1.GetOrderStatusCompletedEventArgs e)
        {
            txt_Status.Text = e.Result;
        }
    }
}
