﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf_client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            string loginid = txt_loginid.Text;
            string password = txt_password.Password;
            ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("NetTcpBinding_IService");
            //ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("BasicHttpBinding_IService");
            proxy.Open();
            proxy.GetOrderStatus(141);
            if(proxy.validateLogin(loginid,password))
            {
                MessageBox.Show("Valid User");
            }
            else
            {
                MessageBox.Show("Invalid User");
                proxy.Logout();
            }
            proxy.Close();
        }

        private void btn_login2_Click(object sender, RoutedEventArgs e)
        {
            string loginid = txt_loginid.Text;
            string password = txt_password.Password;
            ServiceReference2.ServiceClient proxy2 = new ServiceReference2.ServiceClient("WSHttpBinding_IService1");
            //ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("BasicHttpBinding_IService");
            proxy2.Open();
            if (proxy2.Login(loginid, password))
            {
                MessageBox.Show("Valid User");
            }
            else
            {
                MessageBox.Show("Invalid User");
          
            }
            proxy2.Close();
        }
    }
}
