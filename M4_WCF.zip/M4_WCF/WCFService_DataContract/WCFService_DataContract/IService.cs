﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;
namespace WCFService_DataContract
{
     [ServiceContract(SessionMode=SessionMode.Required)]
    interface IService
    {
        [OperationContract(IsInitiating = false, IsTerminating = false)]
         [FaultContract(typeof(ErrorInfo))]
        int AddCustomer(CustomerInfo obj);
         [OperationContract(IsInitiating = false, IsTerminating = false)]
        CustomerInfo FindCustomer(int Id);
         [OperationContract(IsInitiating=false,IsTerminating=false)]
        List<CustomerInfo> GetCustomer(string city);
         [OperationContract]
         List<CustomerInfo> GetAllCustomers();
         [OperationContract(IsInitiating=true,IsTerminating=false)]
         bool Login(string UserID, string Password);

         [OperationContract(IsInitiating=true,IsTerminating=false)]
         void Logout();
          [OperationContract(IsInitiating = false, IsTerminating = false)]
         string GetUserDetails();
    }
}
