﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace WCFService_DataContract
{
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession,ConcurrencyMode=ConcurrencyMode.Multiple)]
    class Service:IService
    {
        public Service()
        {
            Console.WriteLine("Service Object Created....");
        }
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCustomer(CustomerInfo obj)
        {
            try
            {
                int rowaffected;
                SqlCommand com_customer_ad = new SqlCommand("insert into Customer_138281A values(@cname,@ccity)", cn);
                com_customer_ad.Parameters.AddWithValue("@cname", obj.Name);
                com_customer_ad.Parameters.AddWithValue("@ccity", obj.City);
                cn.Open();
                rowaffected = com_customer_ad.ExecuteNonQuery();
                SqlCommand com_customerid = new SqlCommand("select @@identity", cn);
                obj.Id = Convert.ToInt32(com_customerid.ExecuteScalar());
                cn.Close();
                return obj.Id;
            }
            catch(Exception ex)
            {
                //throw new FaultException("SQL Database Error"); //untype Error handling
                ErrorInfo info = new ErrorInfo();
                info.ErrorID = "1001";
                info.ErrorType = "SQL";
                info.ErrorDetails = ex.Message;
                info.ErrorDateTime = DateTime.Now.ToString();
                throw new FaultException<ErrorInfo>(info);

            }
            finally
            {
                if(cn.State==System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
        }

        public CustomerInfo FindCustomer(int Id)
        {
            SqlCommand cn_find = new SqlCommand("Select * from Customer_138281A where Id=@Id", cn);
            cn_find.Parameters.AddWithValue("@Id", Id);
            cn.Open();
            SqlDataReader dr = cn_find.ExecuteReader();
            CustomerInfo obj = null;
            if(dr.Read())
            {
                obj = new CustomerInfo();
                obj.Id = Id;
                obj.Name = dr.GetString(1);
                obj.City = dr.GetString(2);
            }
            cn.Close();
            return obj;
        }

        public List<CustomerInfo> GetCustomer(string city)
        {
            SqlCommand cn_find = new SqlCommand("Select * from Customer_138281A where city=@city", cn);
            cn_find.Parameters.AddWithValue("@city", city);
            cn.Open();
            SqlDataReader dr = cn_find.ExecuteReader();
            List<CustomerInfo> clist = new List<CustomerInfo>();
            while(dr.Read())
            {
                CustomerInfo obj = new CustomerInfo();
                obj.Id = dr.GetInt32(0);
                obj.Name = dr.GetString(1);
                obj.City = dr.GetString(2);
                clist.Add(obj);
            }
            cn.Close();
            return clist;
        }

        string userid;
        public bool Login(string UserID, string Password)
        {
         if(UserID.StartsWith("user") && Password=="pass@123")
         {
             userid = UserID;
             return true;
         }
         return false;
        }

        public void Logout()
        {
            Console.WriteLine("Logout: " + userid);
        }


        public string GetUserDetails()
        {
            return "User Id: " + userid + " ,Name : " + "John";
        }


        public List<CustomerInfo> GetAllCustomers()
        {
            SqlCommand cn_find = new SqlCommand("Select * from Customer_138281A", cn);
            cn.Open();
            SqlDataReader dr = cn_find.ExecuteReader();
            List<CustomerInfo> clist = new List<CustomerInfo>();
            while (dr.Read())
            {
                CustomerInfo obj = new CustomerInfo();
                obj.Id = dr.GetInt32(0);
                obj.Name = dr.GetString(1);
                obj.City = dr.GetString(2);
                clist.Add(obj);
            }
            cn.Close();
            return clist;
        }
    }
}
