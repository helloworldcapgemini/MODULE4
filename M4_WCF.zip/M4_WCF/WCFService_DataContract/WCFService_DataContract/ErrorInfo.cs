﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace WCFService_DataContract
{
   public class ErrorInfo
    {
       [DataMember]
        public string ErrorID { get; set; }
        [DataMember]
        public string ErrorType { get; set; }
        [DataMember]
        public string ErrorDetails { get; set; }
        [DataMember]
        public string ErrorDateTime { get; set; }
    }
}
