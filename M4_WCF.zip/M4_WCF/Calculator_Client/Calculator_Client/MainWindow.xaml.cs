﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator_Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ServiceReference1.CalculatorServiceClient client = new ServiceReference1.CalculatorServiceClient("WSHttpBinding_ICalculatorService");
       
        public MainWindow()
        {
            InitializeComponent();
            
        }

        

        private void btn_sum_Click(object sender, RoutedEventArgs e)
        {

            int num1 = Convert.ToInt32(txtnum1.Text);
            int num2 = Convert.ToInt32(txtnum2.Text);
            client.sumCompleted += client_sumCompleted;
            client.sumAsync(num1, num2);



        }

        void client_sumCompleted(object sender, ServiceReference1.sumCompletedEventArgs e)
        {
            txtresult.Text = e.Result.ToString();
        }

        private void btn_sub_Click(object sender, RoutedEventArgs e)
        {
            int num1 = Convert.ToInt32(txtnum1.Text);
            int num2 = Convert.ToInt32(txtnum2.Text);
            client.SubtractCompleted += client_SubtractCompleted;
            client.SubtractAsync(num1, num2);
        }

        void client_SubtractCompleted(object sender, ServiceReference1.SubtractCompletedEventArgs e)
        {
            txtresult.Text = e.Result.ToString();
        }

        private void btn_mul_Click(object sender, RoutedEventArgs e)
        {
            int num1 = Convert.ToInt32(txtnum1.Text);
            int num2 = Convert.ToInt32(txtnum2.Text);
            client.MultiplyCompleted += client_MultiplyCompleted;
            client.MultiplyAsync(num1, num2);
        }

        void client_MultiplyCompleted(object sender, ServiceReference1.MultiplyCompletedEventArgs e)
        {
            txtresult.Text = e.Result.ToString();
        }

        private void btn_div_Click(object sender, RoutedEventArgs e)
        {
            int num1 = Convert.ToInt32(txtnum1.Text);
            int num2 = Convert.ToInt32(txtnum2.Text);
            client.DivisionCompleted += client_DivisionCompleted;
            client.DivisionAsync(num1, num2);
        }

        void client_DivisionCompleted(object sender, ServiceReference1.DivisionCompletedEventArgs e)
        {
            txtresult.Text = e.Result.ToString();
        }
    }
}
