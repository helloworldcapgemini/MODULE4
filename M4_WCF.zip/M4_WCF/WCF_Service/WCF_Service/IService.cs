﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace WCF_Service
{
    [ServiceContract]
   public interface IService
    {
        [OperationContract]
       bool validateLogin(string UserID, string Password);
        [OperationContract]
       string GetOrderStatus(int OrderID);

        [OperationContract]
        void Logout();
        [OperationContract(Name="XYZ")]
        void Logout(string str);
    }
}
