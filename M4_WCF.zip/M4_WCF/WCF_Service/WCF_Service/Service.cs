﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace WCF_Service
{
  public class Service:IService
    {
      public Service()
      {
          Console.WriteLine("Service Object Created.....");
      }

        public bool validateLogin(string UserID, string Password)
        {
            
            if (UserID == "user1" && Password == "pass@123")
            {
                return true;
            }
            else
                return false;
        }

        public string GetOrderStatus(int OrderID)
        {
            System.Threading.Thread.Sleep(1000);
            return ("Order is Pending.......:" + OrderID);
        }


        public void Logout()
        {
            Console.WriteLine("Log Out Called");
        }


        public void Logout(string str)
        {
            Console.WriteLine(str);
        }
    }
}
