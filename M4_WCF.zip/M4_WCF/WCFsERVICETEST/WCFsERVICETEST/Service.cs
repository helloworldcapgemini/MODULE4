﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IContractLibrary;
namespace WCFsERVICETEST
{
    class Service:IContractLibrary.IService
    {

        public string GetInfo(string UserId)
        {
 	        return "Hello from service  "+UserId;
        }
    }
}
