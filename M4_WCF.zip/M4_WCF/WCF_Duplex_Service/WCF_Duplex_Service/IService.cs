﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace WCF_Duplex_Service
{
    [ServiceContract(CallbackContract=typeof(ICallBack))]
   public interface IService
    {
       [OperationContract(IsOneWay = true)]
       void GetOrdersInfo();
    }
    public interface ICallBack
    {
        [OperationContract(IsOneWay=true)]
        void SendOrders(List<OrderInfo> ords);
    }
}
