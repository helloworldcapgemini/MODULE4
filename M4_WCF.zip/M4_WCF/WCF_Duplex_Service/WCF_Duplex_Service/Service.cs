﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace WCF_Duplex_Service
{
    class Service:IService
    {
        public void GetOrdersInfo()
        {
            List<OrderInfo> ordslist = new List<OrderInfo>();
            ordslist.Add(new OrderInfo { OrderID = 1001, OrderAMT = 5050, CustomerName = "Nikhil" });
            ordslist.Add(new OrderInfo { OrderID = 1002, OrderAMT = 5040, CustomerName = "Nikhil agarwal" });
            ordslist.Add(new OrderInfo { OrderID = 1003, OrderAMT = 5030, CustomerName = "Nikhil Kumar" });
            ordslist.Add(new OrderInfo { OrderID = 1001, OrderAMT = 5040, CustomerName = "N" });

            ICallBack clientref=OperationContext.Current.GetCallbackChannel<ICallBack>();

            clientref.SendOrders(ordslist);
            System.Threading.Thread.Sleep(3000);
            ordslist.Clear();

            ordslist.Add(new OrderInfo { OrderID = 10301, OrderAMT = 6500, CustomerName = "n" });
            ordslist.Add(new OrderInfo { OrderID = 10401, OrderAMT = 5600, CustomerName = "Nikhil" });

            clientref.SendOrders(ordslist);
            System.Threading.Thread.Sleep(3000);
            ordslist.Clear();

            ordslist.Add(new OrderInfo { OrderID = 10041, OrderAMT = 6500, CustomerName = "Nikhil" });
            ordslist.Add(new OrderInfo { OrderID = 10401, OrderAMT = 7500, CustomerName = "Nikhil" });
            clientref.SendOrders(ordslist);
        }
    }
}
