﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace WCF_Calculator_service
{
    class CalculatorService:ICalculatorService
    {
        public int sum(int num1, int num2)
        {
            return num1 + num2;
        }

        public int Division(int num1, int num2)
        {
            return num1 / num2;
        }

        public int Subtract(int num1, int num2)
        {
            return num1 - num2;
        }

        public int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }
    }
}
