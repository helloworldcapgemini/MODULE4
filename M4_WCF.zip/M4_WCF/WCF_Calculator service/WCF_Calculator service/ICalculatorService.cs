﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace WCF_Calculator_service
{
    [ServiceContract]
   public interface ICalculatorService
    {
        [OperationContract]
        int sum(int num1,int num2);
        [OperationContract]
        int Division(int num1, int num2);
        [OperationContract]
        int Subtract(int num1, int num2);
        [OperationContract]
        int Multiply(int num1, int num2);
    }
}
