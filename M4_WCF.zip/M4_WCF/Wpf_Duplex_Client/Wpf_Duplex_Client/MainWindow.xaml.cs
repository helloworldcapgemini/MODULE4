﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.ServiceModel;
using System.Collections.ObjectModel;
namespace Wpf_Duplex_Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window,ServiceReference1.IServiceCallback
    {
        public MainWindow()
        {
            InitializeComponent();
            dg_orders.ItemsSource = ords_list;
        }
        
        private void btn_getorders_Click(object sender, RoutedEventArgs e)
        {
            ServiceReference1.ServiceClient proxy=new ServiceReference1.ServiceClient(new InstanceContext(this),"WSDualHttpBinding_IService");
            proxy.GetOrdersInfo();
        }

        ObservableCollection<ServiceReference1.OrderInfo> ords_list = new ObservableCollection<ServiceReference1.OrderInfo>();
        public void SendOrders(ServiceReference1.OrderInfo[] ords)
        {
            foreach (ServiceReference1.OrderInfo  item in ords)
            {
                ords_list.Add(item);
            }
        }
    }
}
