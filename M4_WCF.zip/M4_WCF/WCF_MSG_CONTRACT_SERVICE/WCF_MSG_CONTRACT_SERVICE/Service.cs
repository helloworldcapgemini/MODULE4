﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCF_MSG_CONTRACT_SERVICE
{
    class Service:IService
    {
        public CustomerDetails GetCustomerInfo(CustomerIDInput obj)
        {
            CustomerDetails details = new CustomerDetails();
            details.CustomerID = obj.CustomerID;
            details.CustomerName = "ABCD";
            return details;
        }
    }
}
