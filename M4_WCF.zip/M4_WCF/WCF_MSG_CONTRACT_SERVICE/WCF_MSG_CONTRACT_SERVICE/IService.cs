﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;
namespace WCF_MSG_CONTRACT_SERVICE
{
    [ServiceContract]
   public interface IService
    {
        [OperationContract]
       CustomerDetails GetCustomerInfo(CustomerIDInput obj);
    }
}
