﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;
namespace WCF_MSG_CONTRACT_SERVICE
{
    [MessageContract]
   public class CustomerDetails
    {
        [MessageHeader]
        public int CustomerID { get; set; }
        [MessageBodyMember]
        public string CustomerName { get; set; }
    }

    [MessageContract]
    public class CustomerIDInput
    {
        [MessageBodyMember]
        public int CustomerID { get; set; }
    }
}
