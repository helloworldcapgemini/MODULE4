﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.ServiceModel;
namespace WCF_DATA_CONTRACT_CLIENT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        ServiceReference1.ServiceClient proxy = new ServiceReference1.ServiceClient("WSHttpBinding_IService");

        private void btn_add_Click_1(object sender, RoutedEventArgs e)
        {
           
            if((sender as Button).Name=="btn_add")
            {
                try
                {
                    ServiceReference1.CustomerInfo obj = new ServiceReference1.CustomerInfo();
                    obj.Name = txt_name.Text;
                    obj.City = txt_city.Text;
                    obj.Id = proxy.AddCustomer(obj);
                    txt_id.Text = obj.Id.ToString();
                }
                catch(FaultException<ServiceReference1.ErrorInfo> ex)
                {
                    MessageBox.Show(ex.Detail.ErrorID+"\n"+ex.Detail.ErrorType+"\n"+ex.Detail.ErrorDetails+"\n"+ex.Detail.ErrorDateTime);
                }
            }
            else if((sender as Button).Name=="btn_find")
            {
                int id = Convert.ToInt32(txt_id.Text);
                ServiceReference1.CustomerInfo objinfo = proxy.FindCustomer(id);
                if(objinfo!=null)
                {
                    txt_city.Text = objinfo.City;
                    txt_name.Text = objinfo.Name;
                    txt_id.Text = objinfo.Id.ToString();
                }
                else
                {
                    MessageBox.Show("Customer Not Found");
                }
            }
            else if((sender as Button).Name=="btn_get_Customers")
            {
                dg_customers.ItemsSource = proxy.GetCustomer(txt_city.Text);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if((sender as Button).Name=="btn_login")
            {
                if(proxy.Login(txtuserid.Text,txtpass.Password))
                {
                    MessageBox.Show("Valid User");
                }
                else
                {
                    MessageBox.Show("InValid User");
                }
            }
            else if((sender as Button).Name=="btn_logout")
            {
                proxy.Logout();
            }
            else if((sender as Button).Name=="btn_details")
            {
                string str = proxy.GetUserDetails();
                MessageBox.Show(str);
            }
        }

        private void btn_show_Customers_Click(object sender, RoutedEventArgs e)
        {
            dg_customers.ItemsSource = proxy.GetAllCustomers();
        }
    }
}
