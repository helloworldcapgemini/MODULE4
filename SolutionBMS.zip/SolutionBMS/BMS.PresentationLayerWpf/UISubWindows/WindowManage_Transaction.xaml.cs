﻿using BMS.BusinessLayer;
using BMS.Entities;
using BMS.Exceptions;
using BMS.PresentationLayerWpf.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace BMS.PresentationLayerWpf.UISubWindows
{
    /// <summary>
    /// Interaction logic for WindowManage_Transaction.xaml
    /// </summary>
    public partial class WindowManage_Transaction : Window
    {
        Button btnAdd = null;
        Button btnReset = null;

        Button btnUpdate = null;
        Button btnDelete = null;

        IBAL<BmsTransaction> bal = null;
        TextBlock applicationStatus = null;



        DispatcherTimer clock = null;

        public WindowManage_Transaction()
        {
            InitializeComponent();

            clock = new DispatcherTimer();
            clock.Tick += new EventHandler(clock_Tick);
            clock.Interval = new TimeSpan(0, 0, 3);

        }

        public void Attach(IBAL<BmsTransaction> bal, TextBlock applicationStatus, ActionMode mode = ActionMode.ADD, object value = null)
        {


            this.bal = bal;
            this.applicationStatus = applicationStatus;

            switch (mode)
            {
                case ActionMode.ADD:
                    {
                        txbTransactionID.Visibility = System.Windows.Visibility.Hidden;
                        txtTransactionID.Visibility = System.Windows.Visibility.Hidden;
                        txtTransactionID.Text = "-1";

                        btnAdd = new Button();
                        btnAdd.Name = "btnAdd";
                        btnAdd.Click += btnAdd_Click;
                        btnAdd.Content = "Transaction";
                        stackButtons.Children.Add(btnAdd);

                        btnReset = new Button();
                        btnReset.Name = "btnReset";
                        btnReset.Click += btnReset_Click;
                        btnReset.Content = "Reset";
                        stackButtons.Children.Add(btnReset);

                    }
                    break;

                case ActionMode.UPDATE:
                    {
                        PopulateFields((BmsTransaction)value);
                        EditableFields();
                        btnUpdate = new Button();
                        btnUpdate.Name = "btnUpdate";
                        btnUpdate.Click += btnUpdate_Click;
                        btnUpdate.Content = "Edit";
                        stackButtons.Children.Add(btnUpdate);

                    }
                    break;

                case ActionMode.DELETE:
                    {
                        EditableFields();
                        PopulateFields((BmsTransaction)value);
                        btnDelete = new Button();
                        btnDelete.Name = "btnDelete";
                        btnDelete.Click += btnDelete_Click;
                        btnDelete.Content = "Delete";
                        stackButtons.Children.Add(btnDelete);

                    }
                    break;
            }

        }

        void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (bal == null) return;
                bool state = bal.Remove(FetchData());
                if (state)
                {
                    applicationStatus.Text = "Inventory Information Deleted Successfully.";
                    applicationStatusMessage.Text = "Inventory Information Deleted Successfully.";
                }
                else
                {
                    applicationStatus.Text = "Failed Deleting Inventory Information.";
                    applicationStatusMessage.Text = "Failed Deleting Inventory Information.";
                }
                //clock.Start();
                applicationStatus.Text = "Ready";
                ClearFields();
                EditableFields();
                btnDelete.IsEnabled = false;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (ConnectedDalException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }



        void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (bal == null) return;
                bool state = bal.Add(FetchData());

                if (state)
                {
                    applicationStatus.Text = "Blood Transaction Information Added Successfully.";
                    applicationStatusMessage.Text = "Blood Transaction Information Added Successfully.";
                }
                else
                {
                    applicationStatus.Text = "Failed Adding Blood Transaction Information.";
                    applicationStatusMessage.Text = "Blood Transaction Information Added Successfully.";
                }
                clock.Start();

                ClearFields();
                txtTransactionID.Text = "-1";
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (ConnectedDalException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (btnUpdate == null) return;

                if ((string)btnUpdate.Content.ToString() == "Edit")
                {
                    EditableFields(true);
                    btnUpdate.Content = "Update";
                }
                else
                {
                    //EditableFields();
                    //btnUpdate.Content = "Edit";
                    if (bal == null) return;
                    bool state = bal.Modify(FetchData());
                    if (state)
                    {
                        applicationStatus.Text = "Blood Transaction Information Updated Successfully.";
                        applicationStatusMessage.Text = "Blood Transaction Information Updated Successfully.";
                    }
                    else
                    {
                        applicationStatus.Text = "Failed updating Blood Transaction Information.";
                        applicationStatusMessage.Text = "Failed updating Blood Transaction Information.";
                    }
                    clock.Start();

                    //ClearFields();
                }

            }
            catch (ValidationException)
            {
                throw;
            }
            catch (ConnectedDalException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        void btnReset_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ClearFields();
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (ConnectedDalException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        void clock_Tick(object sender, EventArgs e)
        {
            applicationStatusMessage.Text = "";
            applicationStatus.Text = "Ready";
            clock.Stop();

        }

        void EditableFields(bool state = false)
        {
            txtBloodInventoryID.IsEnabled = state;
            txtCreationDate.IsEnabled = state;
            txtHospitalID.IsEnabled = state;
            txtNumberofBottles.IsEnabled = state;
            txtTransactionID.IsEnabled = state;
        }

        void ClearFields()
        {

            txtBloodInventoryID.Text = "";
            txtCreationDate.Text = "";
            txtHospitalID.Text = "";
            txtNumberofBottles.Text = "";
            txtTransactionID.Text = "";

        }

        void PopulateFields(BmsTransaction value)
        {
            txtBloodInventoryID.Text = value.BloodInventoryID.ToString() ;
            txtCreationDate.Text = value.CreationDate.ToShortDateString();
            txtHospitalID.Text = value.HospitalID.ToString();
            txtNumberofBottles.Text = value.NumberofBottles.ToString();
            txtTransactionID.Text = value.TransactionID.ToString();

        }


        BmsTransaction FetchData()
        {
            BmsTransaction value = new BmsTransaction();
            value.BloodInventoryID = int.Parse(txtBloodInventoryID.Text);
            value.HospitalID = int.Parse(txtHospitalID.Text);
            value.TransactionID = int.Parse(txtTransactionID.Text);

            value.CreationDate = Convert.ToDateTime(txtCreationDate.Text);
            value.NumberofBottles = int.Parse(txtNumberofBottles.Text);
            
            return value;
        }

    }
}
