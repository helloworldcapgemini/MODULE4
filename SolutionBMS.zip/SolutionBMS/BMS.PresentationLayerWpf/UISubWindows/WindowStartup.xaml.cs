﻿using BMS.BusinessLayer;
using BMS.Entities;
using BMS.PresentationLayerWpf.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;



namespace BMS.PresentationLayerWpf.UISubWindows
{
    /// <summary>
    /// Interaction logic for WindowStartup.xaml
    /// </summary>
    public partial class WindowStartup : Window
    {

        IBAL<BmsBloodBank> balBank = null;
        IBAL<BmsBloodDonationCamp> balCamp = null;
        IBAL<BmsBloodDonor> balDonor = null;
        IBAL<BmsBloodDonorDonation> balDonation = null;
        IBAL<BmsBloodInventory> balInventory = null;
        IBAL<BmsHospital> balHospital = null;
        IBAL<BmsTransaction> balTransaction = null;
        TextBlock applicationStatus = null;

        int MonthRange = 12;

        public WindowStartup()
        {
            InitializeComponent();

           // Charting.SetPieChart(bloodByGroup, ColorShades.redShades, Charting.bloodByGroupData);
           // Charting.SetPieChart(hospitalDemand, ColorShades.greenShades, Charting.hospitalDemandData);

            List<List<KeyValuePair<string, int>>> list = new List<List<KeyValuePair<string, int>>>();
            list.Add(Charting.bloodTransactionData);
            list.Add(Charting.bloodTransactionData2);

            Charting.SetBarChart(bloodTransactionBar, list);

        }


        public void Attach(IBAL<BmsBloodBank> balBank, IBAL<BmsBloodDonationCamp> balCamp, IBAL<BmsBloodDonor> balDonor,
            IBAL<BmsBloodDonorDonation> balDonation, IBAL<BmsBloodInventory> balInventory, IBAL<BmsHospital> balHospital,
             IBAL<BmsTransaction> balTransaction, TextBlock applicationStatus)
        {
            this.balBank = balBank;
            this.balCamp = balCamp;
            this.balDonor = balDonor;
            this.balDonation = balDonation;
            this.balInventory = balInventory;
            this.balHospital = balHospital;
            this.balTransaction = balTransaction;

            this.applicationStatus = applicationStatus;

            CalanderReg();
            CalanderEvent();
            CalanderTrans();

            PieBloodByGroup();
            PieAllDonorHBCounts();

            BarDonorWeightDistribution();
            BarChartTransaction();
            BarChartVolumeOfBloodInventory();

        }

        private void CalanderReg()
        {
            List<DateTime> list = null;
            list = (from e in balDonor.GetAll() where e.CreationDate < DateTime.Now.AddMonths(MonthRange) && e.CreationDate > DateTime.Now.AddMonths(-MonthRange) select e.CreationDate).ToList();

            Style s = (Style)Resources["styleCalendarDayButtonStyleReg"];
            foreach (var holidayDates in list)
            {
                DataTrigger dataTrigger = new DataTrigger() { Binding = new Binding("Date"), Value = holidayDates };
                dataTrigger.Setters.Add(new Setter(System.Windows.Controls.Primitives.CalendarDayButton.BackgroundProperty, Brushes.GreenYellow));
                s.Triggers.Add(dataTrigger);
            }

        }

        private void CalanderEvent()
        {
            List<DateTime> list = null;
            list = (from e in balCamp.GetAll() where e.CampStartDate < DateTime.Now.AddMonths(MonthRange) && e.CampStartDate > DateTime.Now.AddMonths(-MonthRange) select e.CampStartDate).ToList();

            Style s = (Style)Resources["styleCalendarDayButtonStyleEvent"];
            foreach (var holidayDates in list)
            {
                DataTrigger dataTrigger = new DataTrigger() { Binding = new Binding("Date"), Value = holidayDates };
                dataTrigger.Setters.Add(new Setter(System.Windows.Controls.Primitives.CalendarDayButton.BackgroundProperty, Brushes.DeepSkyBlue));
                s.Triggers.Add(dataTrigger);
            }

        }

        private void CalanderTrans()
        {
            List<DateTime> list = null;
            //list = (from e in balTransaction.GetAll() where e.CreationDate < DateTime.Now.AddMonths(MonthRange) && e.CreationDate > DateTime.Now.AddMonths(-MonthRange) select e.CreationDate).ToList();
            list = (from e in balTransaction.GetAll() where e.CreationDate < DateTime.Now.AddMonths(MonthRange) && e.CreationDate > DateTime.Now.AddMonths(-MonthRange) select e.CreationDate).ToList();

            Style s = (Style)Resources["styleCalendarDayButtonStyleTrans"];
            foreach (var holidayDates in list)
            {
                DataTrigger dataTrigger = new DataTrigger() { Binding = new Binding("Date"), Value = holidayDates };
                dataTrigger.Setters.Add(new Setter(System.Windows.Controls.Primitives.CalendarDayButton.BackgroundProperty, Brushes.OrangeRed));
                s.Triggers.Add(dataTrigger);
            }

        }

        private void PieBloodByGroup()
        {
            
            List<KeyValuePair<string, int>> list = new List<KeyValuePair<string, int>>();

            var inventories = balInventory.GetAll().Where( item => item.BloodBankID == MainWindow.CurrentAdminSystem.BloodBankID);
            var inventoryByGroup = inventories.GroupBy(inventory => inventory.BloodGroup).Select(group => new { Key = group.Key, Count = group.Sum( bottles => bottles.NumberofBottles) }).OrderBy(x => x.Key);
            foreach (var item in inventoryByGroup)
            {
                list.Add(new KeyValuePair<string, int>(item.Key, item.Count));

            }
            List<string> colors = ColorShades.blueRedShades.ToList();
            colors.Reverse();
            Charting.SetPieChart(bloodByGroup, colors, list);
        }

        private void BarChartVolumeOfBloodInventory()
        {

            List<KeyValuePair<string, int>> list = new List<KeyValuePair<string, int>>();
            var inventories = balInventory.GetAll().Where(item => item.BloodBankID == MainWindow.CurrentAdminSystem.BloodBankID);
            var inventoryByGroup = inventories.GroupBy(inventory => inventory.BloodInventoryID).Select(group => new { Key = group.Key, Count = group.Sum(bottles => bottles.NumberofBottles) }).OrderBy(x => x.Key);
            int inventoryCount = 1;
            foreach (var item in inventoryByGroup)
            {
                list.Add(new KeyValuePair<string, int>((inventoryCount++).ToString(), item.Count));

            }
            VolumeOfBloodInventory.DataContext = list;

        }




        private void BarDonorWeightDistribution()
        {

            List<KeyValuePair<string, int>> list = new List<KeyValuePair<string, int>>();

            var donorsWeights = balDonation.GetAll().GroupBy(donor => donor.Weight).Select(group => new { Key = group.Key, Count = group.Count() }).OrderBy(x => x.Key);
            

            foreach (var item in donorsWeights)
            {
                list.Add(new KeyValuePair<string, int>(item.Key.ToString(), item.Count));

            }
            donorWeightDistribution.DataContext = list;
        }


        private void PieAllDonorHBCounts()
        {
            List<KeyValuePair<string, int>> list = new List<KeyValuePair<string, int>>();
            var donations = balDonation.GetAll().GroupBy(donor => donor.HBCount).Select(group => new { Key = group.Key, Count = group.Count() }).OrderBy(x => x.Key);


            foreach (var item in donations)
            {
                list.Add(new KeyValuePair<string, int>(item.Key.ToString(), item.Count));

            }
            List<string> colors = ColorShades.blueRedShades.ToList();
            //colors.Reverse();
            Charting.SetPieChart(pieChartAllDonorHBCounts, colors, list);
        }


        private void BarChartTransaction()
        {

            List<KeyValuePair<string, int>> list = new List<KeyValuePair<string, int>>();
            var inventories = (from item in balInventory.GetAll() where item.BloodBankID == MainWindow.CurrentAdminSystem.BloodBankID select item.BloodInventoryID).ToList();

            var transactions = balTransaction.GetAll().Where(item => inventories.Contains(item.BloodInventoryID));
            var transactionGroupBy = transactions.GroupBy(trans => trans.HospitalID).Select(group => new { Key = group.Key, Count = group.Sum(bottles => bottles.NumberofBottles) }).OrderBy(x => x.Key);

            int inventoryCount = 1;
            foreach (var item in transactionGroupBy)
            {
                list.Add(new KeyValuePair<string, int>((inventoryCount++).ToString(), item.Count));

            }
            
            
           
            bloodTransactionBar.DataContext = list;
        }





        private void calDonorReg_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
        {
            SelectedDatesCollection cc = calDonorReg.SelectedDates;

            foreach (var item in cc)
            {
                Debug.WriteLine(item.ToShortDateString());
                //list.Items.Add(item.ToShortDateString());
            }
        }

        private void calDonorReg_DisplayDateChanged(object sender, CalendarDateChangedEventArgs e)
        {
            MessageBox.Show(calDonorReg.SelectedDate.ToString());
        }

      


    }
}
