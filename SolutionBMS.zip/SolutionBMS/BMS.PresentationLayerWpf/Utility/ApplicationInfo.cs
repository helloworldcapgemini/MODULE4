﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMS.PresentationLayerWpf.Utility
{
    public class ApplicationInfo
    {
        public static string APPNAME = "BMS";
        public static string APPFULLNAME = "Blood Management System";
        public static string VERSION = "1.0";

    }
}
